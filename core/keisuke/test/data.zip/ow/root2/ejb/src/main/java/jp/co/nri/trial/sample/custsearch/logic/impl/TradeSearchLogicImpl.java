package jp.co.nri.trial.sample.custsearch.logic.impl;
/* zzz コメントの修正のみで有効行修正なし */
/* zzz 複数行コメントの追加
　hoge
	hoge
*/

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;

import jp.co.nri.kinshasa.aplcommons.model.Aina;
import jp.co.nri.kinshasa.aplcommons.model.Mina;
import jp.co.nri.kinshasa.aplcommons.util.mapping.BeanMappingUtil;
import jp.co.nri.kinshasa.aplcommons.util.mapping.IMapper;
import jp.co.nri.kinshasa.framework.log.LogManager;
import jp.co.nri.kinshasa.framework.log.Logger;
import jp.co.nri.trial.sample.custsearch.dao.KokyakuDbDao;
import jp.co.nri.trial.sample.custsearch.dao.TradeDbDao;
import jp.co.nri.trial.sample.custsearch.dao.dto.Trade;
import jp.co.nri.trial.sample.custsearch.common.LogMessage;
import jp.co.nri.trial.sample.custsearch.logic.TradeSearchLogic;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎丸 zzz コメント行の修正
 */
@Stateless
@Name("tradeSearchLogic")
public class TradeSearchLogicImpl implements TradeSearchLogic {
	
	@In(create = true)
	// コンテキストにtradeDbDaoが存在しない場合は新たに生成します。
	// zzz コメント行の追加＆下の空行の追加

	private TradeDbDao tradeDbDao; // zzz 有効行の行末にコメント追記
	
	@In(create = true)
	// コンテキストにkokyakuDbDaoが存在しない場合は新たに生成します。
	private KokyakuDbDao kokyakuDbDao;
	
	@In
	private Aina aina;

	private IMapper mapper = BeanMappingUtil.getInstance();
	
	//ログ出力部品の定義
	protected Logger logger = LogManager.getLogger(TradeSearchLogicImpl.class);


	//定数の定義
	private final String SUCCESS_MSG = "";
	private final String ERR_MSG_NO_TRADE_RESULT = "該当する取引データが存在しません";

	/**
	 * 一覧検索
	 */
	public jp.co.nri.trial.sample.custsearch.logic.dto.TradeLogicOutDto searchTrade(
			jp.co.nri.trial.sample.custsearch.logic.dto.TradeLogicInDto logicInDto) {
		
		// サービス層へ返すOutDtoの準備
		jp.co.nri.trial.sample.custsearch.logic.dto.TradeLogicOutDto logicOutDto = new jp.co.nri.trial.sample.custsearch.logic.dto.TradeLogicOutDto();

		// ステータス・メッセージのセットの準備
		Mina mina = new Mina();

		// DAOの呼び出し、検索実行
		List<Trade> resultList = tradeDbDao.selectByKokyakuCd(logicInDto
				.getSelected_kokyakulist().getKokyaku_cd());

		// 取得結果が無ければ、戻りステータスに検索失敗を設定
		if (resultList.size() <= 0) {
			mina.setMSG_TEXT_SUMMARY(ERR_MSG_NO_TRADE_RESULT);
			logger.log(LogMessage.CSAPLLOG03);

		} else {
			// Tradeのリストを作成し、検索結果から値をマッピングしたTradeを加える
			logicOutDto.setTradelist(new ArrayList<Trade>());
			for (Trade result : resultList) {
				logicOutDto.getTradelist().add(
						(Trade) mapper.map(result, Trade.class));
			}
			mina.setMSG_TEXT_SUMMARY(SUCCESS_MSG);
			logger.log(LogMessage.CSAPLLOG04);
		}
		aina.setSTATUS_CODE(0);
		aina.addMESSAGES(mina);

		// 検索結果を格納したOutDto（TradeのList）を返す
		return logicOutDto;

	}

}
