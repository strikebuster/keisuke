// zzz コメント行のみの修正、有効行修正なし
/* zzz 複数行コメント追加
 hoge
	hoge
hoge */
// zzz コメント行追加　＆　空行追加


var _kss_client_messages = new Object(); // zzz 行末にコメント追加
_kss_client_messages['validator.isNotNull']='{label}は必須入力項目です。';
_kss_client_messages['validator.isAscii']='{label}にはアスキーコードのみを入力してください。';
_kss_client_messages['validator.isHankaku']='{label}には半角文字のみを入力してください。';
_kss_client_messages['validator.isZenkaku']='{label}には全角文字のみを入力してください。';
_kss_client_messages['validator.isAlphabet']='{label}にはアルファベットのみを入力してください。';
_kss_client_messages['validator.isNumber']='{label}には数字のみを入力してください。';
_kss_client_messages['validator.isAlNum']='{label}には数字かアルファベットのみを入力してください。';
_kss_client_messages['validator.isDate']='{label}には日付を入力してください。';
_kss_client_messages['validator.isInteger']='{label}には整数を入力してください。';
_kss_client_messages['validator.isDecimal']='{label}には数値を入力してください。';
_kss_client_messages['validator.isGreaterThan']='{label}には{value}より大きい数を入力してください。';
_kss_client_messages['validator.isGreaterEqualThan']='{label}には{value}以上の数を入力してください。';
_kss_client_messages['validator.isLessThan']='{label}には{value}より小さい数を入力してください。';
_kss_client_messages['validator.isLessEqualThan']='{label}には{value}以下の数を入力してください。';
_kss_client_messages['validator.minLength']='{label}には{value}文字以上で入力してください。';
_kss_client_messages['validator.maxLength']='{label}には{value}文字以下で入力してください。';
_kss_client_messages['validator.equalLength']='{label}には{value}文字で入力してください。';
_kss_client_messages['validator.rangeLength']='{label}は{min}文字以上、{max}文字以下で入力してください。';
_kss_client_messages['validator.pattern']='{label}には{value}に含まれる文字を入力してください。';
_kss_client_messages['validator.isValidChar']='{label}には{value}に含まれる文字を入力してください。';
_kss_client_messages['validator.notExistYouon']='{label}には半角の促音・拗音は入力できません。';
_kss_client_messages['validator.isDateMMDD']='{label}にはMMDD形式で入力してください。';
_kss_client_messages['validator.email']='{label}にはEメール形式で入力してください。';
_kss_client_messages['validator.isDateYYYYMM']='{label}にはYYYYMM形式で入力してください。';
_kss_client_messages['validator.isDateYYMMDD']='{label}にはYYMMDD形式で入力してください。';
_kss_client_messages['validator.isDateYYMM']='{label}にはYYMM形式で入力してください。';
_kss_client_messages['validator.minByteLength']='{label}には半角では{value}桁以上で入力してください。';
_kss_client_messages['validator.maxByteLength']='{label}には半角では{value}桁以下で入力してください。';
_kss_client_messages['validator.equalByteLength']='{label}には半角では{value}桁で入力してください。';
_kss_client_messages['validator.rangeByteLength']='{label}は半角では{min}桁以上、{max}桁以下で入力してください。';
