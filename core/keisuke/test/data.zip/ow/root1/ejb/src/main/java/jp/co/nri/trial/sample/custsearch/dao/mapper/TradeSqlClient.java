package jp.co.nri.trial.sample.custsearch.dao.mapper;

import java.util.List;

import jp.co.nri.trial.sample.custsearch.dao.dto.Trade;

/**
 * 取引情報取得のインターフェースクラスです。
 * create-date .
 * @author 
 */
public interface TradeSqlClient {
	
	/**
	 * selectByKokyakuCd
	 * @param kokyaku_cd
	 * @return trade list
	 */
	public List<Trade> selectByKokyakuCd(String kokyaku_cd);
	
}
