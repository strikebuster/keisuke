package jp.co.nri.trial.sample.custsearch.dao.impl;

import java.util.List;

import jp.co.nri.kinshasa.framework.log.LogManager;
import jp.co.nri.kinshasa.framework.log.Logger;
import jp.co.nri.trial.sample.custsearch.dao.KokyakuDbDao;
import jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku;
import jp.co.nri.trial.sample.custsearch.dao.dto.KokyakuCondition;
import jp.co.nri.trial.sample.custsearch.dao.mapper.KokyakuSqlClient;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;

/**
 * 顧客情報取得ロジックの実装です。
 * create-date 08/08/01.
 * @author 野村 太郎
 */
@Name("kokyakuDbDao")
public class KokyakuDbDaoImpl implements KokyakuDbDao {
	
	@In(create = true)
	private KokyakuSqlClient kokyakuSqlClient;

	//ログ出力部品の定義
	protected Logger logger = LogManager.getLogger(KokyakuDbDaoImpl.class);

	/**
	 * selectByMultiKeys
	 * 入力された顧客CD、顧客名、取引開始日、担当者CD、ステータスの条件に一致する顧客のリストを返す
	 * create-date 01/08/2008.
	 * @author 野村 太郎
	 * @param kokyakuCondition
	 * @return　result
	 */	
	public List<Kokyaku> selectByMultiKeys(KokyakuCondition kokyakuCondition) {

		// 検索の実行
		List<Kokyaku> result = kokyakuSqlClient.selectByMultiKeys(kokyakuCondition);

		// 検索結果を返す
		return result;
	}

}
