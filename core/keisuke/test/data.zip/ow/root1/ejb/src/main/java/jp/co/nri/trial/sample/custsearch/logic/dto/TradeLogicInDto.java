package jp.co.nri.trial.sample.custsearch.logic.dto;

import java.io.Serializable;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎 
 */
public class TradeLogicInDto implements Serializable {
	private static final long serialVersionUID = 1L;

	@jp.co.nri.kinshasa.aplcommons.annotation.Label("選択された顧客")
	private jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku selected_kokyakulist;

	public void setSelected_kokyakulist(jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku selected_kokyakulist) {
		this.selected_kokyakulist = selected_kokyakulist;
	}

	public jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku getSelected_kokyakulist() {
		return this.selected_kokyakulist;
	}


}
