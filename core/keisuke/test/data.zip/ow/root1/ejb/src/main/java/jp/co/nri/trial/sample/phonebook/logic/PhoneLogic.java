package jp.co.nri.trial.sample.phonebook.logic;

import javax.ejb.Local;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎
 */
@Local
public interface PhoneLogic {

	jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut001Dto searchphone(jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicIn001Dto logicInDto);

	jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut001Dto select(jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicIn001Dto logicInDto);

	jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut002Dto deletephone(jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicIn002Dto logicInDto);

	jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut001Dto createphone(jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicIn001Dto logicInDto);

	jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut002Dto updatephone(jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicIn002Dto logicInDto);

}
