package jp.co.nri.trial.sample.phonebook.dao.mapper;

import java.util.List;

import jp.co.nri.trial.sample.phonebook.dao.dto.Phone;

/**
 * 電話帳情報取得のインターフェースクラスです。
 * create-date 01/08/2008.
 * @author 野村 太郎
 */
public interface PhoneSqlClient {
	
	/**
	 * searchPhoneNo
	 * @return phone list
	 */
	public List<Phone> searchPhoneNo();

	/**
	 * insert
	 * @param Phone
	 */
	public int insert(Phone phone);

	/**
	 * delete
	 * @param Phone
	 */
	public int delete(Phone phone);
	
	/**
	 * selectByPhoneNo
	 * @param phoneNo
	 * @return phone
	 */
	public Phone selectByPhoneNo(String phoneNo);
	
	/**
	 * update
	 * @param phone
	 */
	public int update(Phone phone);
	
}
