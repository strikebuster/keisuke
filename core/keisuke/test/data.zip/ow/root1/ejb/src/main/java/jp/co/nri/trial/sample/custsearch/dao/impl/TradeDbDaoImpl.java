package jp.co.nri.trial.sample.custsearch.dao.impl;

import java.util.List;

import jp.co.nri.kinshasa.framework.log.LogManager;
import jp.co.nri.kinshasa.framework.log.Logger;
import jp.co.nri.trial.sample.custsearch.dao.TradeDbDao;
import jp.co.nri.trial.sample.custsearch.dao.dto.Trade;
import jp.co.nri.trial.sample.custsearch.dao.mapper.TradeSqlClient;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;

/**
 * 取引情報検索ロジックの実装です。
 * create-date 08/08/01.
 * @author 野村 太郎
 */
@Name("tradeDbDao")
public class TradeDbDaoImpl implements TradeDbDao {

	@In(create = true)
	private TradeSqlClient tradeSqlClient;
	
	protected Logger logger = LogManager.getLogger(TradeDbDaoImpl.class);

	/**
	 * selectByKokyakuCd
	 * 入力された顧客CDに一致する取引のリストを返す
	 * @author 野村 太郎
	 * @param kokyakuCd
	 * @return　result
	 */
	public List<Trade> selectByKokyakuCd(String kokyakuCd) {

		List<Trade> result = null;

		// クエリの実行
   		result = tradeSqlClient.selectByKokyakuCd(kokyakuCd);
		return result;
	}

}
