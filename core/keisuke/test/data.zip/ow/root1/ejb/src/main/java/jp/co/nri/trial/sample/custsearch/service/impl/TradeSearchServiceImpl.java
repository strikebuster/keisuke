package jp.co.nri.trial.sample.custsearch.service.impl;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import javax.ejb.Stateless;
import jp.co.nri.kinshasa.aplcommons.model.Aina;
import jp.co.nri.kinshasa.aplcommons.util.mapping.BeanMappingUtil;
import jp.co.nri.kinshasa.aplcommons.util.mapping.IMapper;

import jp.co.nri.trial.sample.custsearch.service.TradeSearchService;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎 
 */
@Stateless
@Name("tradeSearchService")
public class TradeSearchServiceImpl implements TradeSearchService {


	@In(create = true)
	private jp.co.nri.trial.sample.custsearch.logic.TradeSearchLogic tradeSearchLogic;


	@In
	private Aina aina;

	private IMapper mapper = BeanMappingUtil.getInstance();

	public jp.co.nri.trial.sample.custsearch.service.dto.TradeServiceOutDto searchTrade(jp.co.nri.trial.sample.custsearch.service.dto.TradeServiceInDto serviceInDto) {
	
		jp.co.nri.trial.sample.custsearch.logic.dto.TradeLogicInDto logicInDto = (jp.co.nri.trial.sample.custsearch.logic.dto.TradeLogicInDto) mapper.map(serviceInDto, jp.co.nri.trial.sample.custsearch.logic.dto.TradeLogicInDto.class);
		jp.co.nri.trial.sample.custsearch.logic.dto.TradeLogicOutDto logicOutDto = tradeSearchLogic.searchTrade(logicInDto);
		jp.co.nri.trial.sample.custsearch.service.dto.TradeServiceOutDto serviceOutDto = (jp.co.nri.trial.sample.custsearch.service.dto.TradeServiceOutDto) mapper.map(logicOutDto, jp.co.nri.trial.sample.custsearch.service.dto.TradeServiceOutDto.class);
		
		return serviceOutDto;
	}

}
