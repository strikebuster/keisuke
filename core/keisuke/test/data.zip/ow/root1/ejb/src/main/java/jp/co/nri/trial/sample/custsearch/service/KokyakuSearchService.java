package jp.co.nri.trial.sample.custsearch.service;

import javax.ejb.Local;
/**
 * create-date 01/08/2008.
 * @author 野村 太郎 
 */
@Local
public interface KokyakuSearchService {

	jp.co.nri.trial.sample.custsearch.service.dto.KokyakuServiceOutDto searchKokyaku(jp.co.nri.trial.sample.custsearch.service.dto.KokyakuSerivceInDto serviceInDto);
}
