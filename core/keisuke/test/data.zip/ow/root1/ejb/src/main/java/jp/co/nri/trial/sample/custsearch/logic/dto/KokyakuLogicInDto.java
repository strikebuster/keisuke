package jp.co.nri.trial.sample.custsearch.logic.dto;

import java.io.Serializable;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎 
 */
public class KokyakuLogicInDto implements Serializable {
	private static final long serialVersionUID = 1L;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("6")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("顧客コード")
	private String kokyaku_cd;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("50")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("顧客名称（漢字）")
	private String kokyaku_name;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("6")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("担当者コード")
	private String tanto_cd;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSFormatPattern(pattern = ("####/##/##"))
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckDate
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("8")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("取引開始日")
	private String start_date;

	@jp.co.nri.kinshasa.aplcommons.annotation.Label("選択されたステータス")
	private String selected_kokyaku_status;

	public void setKokyaku_cd(String kokyaku_cd) {
		this.kokyaku_cd = kokyaku_cd;
	}

	public String getKokyaku_cd() {
		return this.kokyaku_cd;
	}

	public void setKokyaku_name(String kokyaku_name) {
		this.kokyaku_name = kokyaku_name;
	}

	public String getKokyaku_name() {
		return this.kokyaku_name;
	}

	public void setTanto_cd(String tanto_cd) {
		this.tanto_cd = tanto_cd;
	}

	public String getTanto_cd() {
		return this.tanto_cd;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public String getStart_date() {
		return this.start_date;
	}

	public void setSelected_kokyaku_status(String selected_kokyaku_status) {
		this.selected_kokyaku_status = selected_kokyaku_status;
	}

	public String getSelected_kokyaku_status() {
		return this.selected_kokyaku_status;
	}


}
