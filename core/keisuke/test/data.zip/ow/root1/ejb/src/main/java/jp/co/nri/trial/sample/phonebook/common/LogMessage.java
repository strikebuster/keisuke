package jp.co.nri.trial.sample.phonebook.common;
import jp.co.nri.kinshasa.framework.log.annotation.LogLevel;
import jp.co.nri.kinshasa.framework.message.annotation.Message;

/**
 * Enumによるログ出力のための定義クラスです。
 * create-date 2008/8/1
 * @author 野村 太郎
 */
//全体カテゴリーの指定（省略可能）
//@Category("jp.co.nri.trial.sample")
public enum LogMessage {
	
	@LogLevel(LogLevel.INFO)			//ログレベルの指定
	@Message("COULD NOT FIND PHONE")		//メッセージの指定（顧客検索失敗）
	CS_D_APLLOG01,					//ログメッセージIDの指定（ユニークなIDを設定）

	@LogLevel(LogLevel.INFO)			//ログレベルの指定
	@Message("FOUND PHONE")				//メッセージの指定（顧客検索成功）
	CS_D_APLLOG02,					//ログメッセージIDの指定（ユニークなIDを設定）

	@LogLevel(LogLevel.INFO)			//ログレベルの指定
	@Message("COULD NOT CREATE NEW PHONE")		//メッセージの指定（取引情報検索結果なし）
	CS_D_APLLOG03,					//ログメッセージIDの指定（ユニークなIDを設定）

	@LogLevel(LogLevel.INFO)			//ログレベルの指定
	@Message("CREATE NEW PHONE")			//メッセージの指定（取引情報検索結果なし）
	CS_D_APLLOG04,					//ログメッセージIDの指定（ユニークなIDを設定）

	@LogLevel(LogLevel.INFO)			//ログレベルの指定
	@Message("COULD NOT UPDATE PHONE")		//メッセージの指定（取引情報検索結果なし）
	CS_D_APLLOG05,					//ログメッセージIDの指定（ユニークなIDを設定）

	@LogLevel(LogLevel.INFO)			//ログレベルの指定
	@Message("UPDATE PHONE")			//メッセージの指定（取引情報検索結果なし）
	CS_D_APLLOG06,					//ログメッセージIDの指定（ユニークなIDを設定）

	@LogLevel(LogLevel.INFO)			//ログレベルの指定
	@Message("COULD NOT DELETE PHONE")		//メッセージの指定（取引情報検索結果なし）
	CS_D_APLLOG07,					//ログメッセージIDの指定（ユニークなIDを設定）

	@LogLevel(LogLevel.INFO)			//ログレベルの指定
	@Message("DELETE PHONE")			//メッセージの指定（取引情報検索結果なし）
	CS_D_APLLOG08,					//ログメッセージIDの指定（ユニークなIDを設定）
}
