package jp.co.nri.trial.sample.custsearch.service.dto;

import java.io.Serializable;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎 
 */
public class TradeServiceOutDto implements Serializable {
	private static final long serialVersionUID = 1L;

	@jp.co.nri.kinshasa.aplcommons.annotation.Label("取引一覧")
	private java.util.List<jp.co.nri.trial.sample.custsearch.dao.dto.Trade> tradelist;

	public void setTradelist(java.util.List<jp.co.nri.trial.sample.custsearch.dao.dto.Trade> tradelist) {
		this.tradelist = tradelist;
	}

	public java.util.List<jp.co.nri.trial.sample.custsearch.dao.dto.Trade> getTradelist() {
		return this.tradelist;
	}


}
