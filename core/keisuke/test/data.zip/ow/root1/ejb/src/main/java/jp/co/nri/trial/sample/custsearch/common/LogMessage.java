package jp.co.nri.trial.sample.custsearch.common;

import jp.co.nri.kinshasa.framework.log.annotation.LogLevel;
import jp.co.nri.kinshasa.framework.message.annotation.Message;

/**
 * Enumによるログ出力のための定義クラスです。
 * create-date 08/08/01.
 * @author 野村 太郎
 */
//全体カテゴリーの指定（省略可能）
//@Category("jp.co.nri.trial.sample")
public enum LogMessage {
	
	@LogLevel(LogLevel.INFO)			//ログレベルの指定
	@Message("<I> CSAPLLOG01 COULD NOT FIND KOKYAKU")	//メッセージの指定（顧客検索失敗）
	CSAPLLOG01,							//ログメッセージIDの指定（ユニークなIDを設定）

	@LogLevel(LogLevel.INFO)			//ログレベルの指定
	@Message("<I> CSAPLLOG02 FOUND KOKYAKU")			//メッセージの指定（顧客検索成功）
	CSAPLLOG02,							//ログメッセージIDの指定（ユニークなIDを設定）

	@LogLevel(LogLevel.INFO)			//ログレベルの指定
	@Message("<I> CSAPLLOG03 NO TRADE FOUND")			//メッセージの指定（取引情報検索結果なし）
	CSAPLLOG03,							//ログメッセージIDの指定（ユニークなIDを設定）

	@LogLevel(LogLevel.INFO)			//ログレベルの指定
	@Message("<I> CSAPLLOG04 FOUND TRADE")				//メッセージの指定（取引情報検索結果有り）
	CSAPLLOG04,							//ログメッセージIDの指定（ユニークなIDを設定）
	
	@LogLevel(LogLevel.INFO)			//ログレベルの指定
	@Message("<I> CSAPLLOG99 JPQL : $0")				//メッセージの指定（発行されるJPQLテンプレート）
	CSAPLLOG99,							//ログメッセージIDの指定（ユニークなIDを設定）

}
