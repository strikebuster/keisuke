package jp.co.nri.trial.sample.custsearch.dao;

import java.util.List;

import jp.co.nri.trial.sample.custsearch.dao.dto.Trade;

/**
 * 取引情報取得のインターフェースクラスです。
 * create-date 08/08/01.
 * @author 野村 太郎
 */
public interface TradeDbDao {
	
	/**
	 * selectByKokyakuCd
	 */
	public List<Trade> selectByKokyakuCd(String kokyakuCd);

}
