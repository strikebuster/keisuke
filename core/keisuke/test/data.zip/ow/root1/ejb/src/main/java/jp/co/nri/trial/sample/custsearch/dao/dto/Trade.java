package jp.co.nri.trial.sample.custsearch.dao.dto;

import java.io.Serializable;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎
 */
public class Trade implements Serializable {
	private static final long serialVersionUID = 1L;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("6")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("顧客コード")
	private String kokyaku_cd;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("6")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("取引CD")
	private String torihiki_cd;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSFormatPattern(pattern = ("####/##/##"))
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckDate
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("8")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("売上日")
	private String uriage_date;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("6")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("商品コード")
	private String syohin_cd;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("20")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("商品名")
	private String syohin_name;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckDecimal
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("3")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("数量")
	private java.math.BigDecimal uriage_count;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSFormatPattern(pattern = ("#,###,###,##0"))
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckDecimal
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("12")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("金額")
	private java.math.BigDecimal uriage_amount;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("1")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("取引状況")
	private String trade_status;

	public void setKokyaku_cd(String kokyaku_cd) {
		this.kokyaku_cd = kokyaku_cd;
	}

	public String getKokyaku_cd() {
		return this.kokyaku_cd;
	}

	public void setTorihiki_cd(String torihiki_cd) {
		this.torihiki_cd = torihiki_cd;
	}

	public String getTorihiki_cd() {
		return this.torihiki_cd;
	}

	public void setUriage_date(String uriage_date) {
		this.uriage_date = uriage_date;
	}

	public String getUriage_date() {
		return this.uriage_date;
	}

	public void setSyohin_cd(String syohin_cd) {
		this.syohin_cd = syohin_cd;
	}

	public String getSyohin_cd() {
		return this.syohin_cd;
	}

	public void setSyohin_name(String syohin_name) {
		this.syohin_name = syohin_name;
	}

	public String getSyohin_name() {
		return this.syohin_name;
	}

	public void setUriage_count(java.math.BigDecimal uriage_count) {
		this.uriage_count = uriage_count;
	}

	public java.math.BigDecimal getUriage_count() {
		return this.uriage_count;
	}

	public void setUriage_amount(java.math.BigDecimal uriage_amount) {
		this.uriage_amount = uriage_amount;
	}

	public java.math.BigDecimal getUriage_amount() {
		return this.uriage_amount;
	}

	public void setTrade_status(String trade_status) {
		this.trade_status = trade_status;
	}

	public String getTrade_status() {
		return this.trade_status;
	}


}
