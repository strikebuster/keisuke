package jp.co.nri.trial.sample.custsearch.service.impl;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import javax.ejb.Stateless;
import jp.co.nri.kinshasa.aplcommons.model.Aina;
import jp.co.nri.kinshasa.aplcommons.util.mapping.BeanMappingUtil;
import jp.co.nri.kinshasa.aplcommons.util.mapping.IMapper;

import jp.co.nri.trial.sample.custsearch.service.KokyakuSearchService;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎 
 */
@Stateless
@Name("kokyakuSearchService")
public class KokyakuSearchServiceImpl implements KokyakuSearchService {


	@In(create = true)
	private jp.co.nri.trial.sample.custsearch.logic.KokyakuSearchLogic kokyakuSearchLogic;


	@In
	private Aina aina;

	private IMapper mapper = BeanMappingUtil.getInstance();

	public jp.co.nri.trial.sample.custsearch.service.dto.KokyakuServiceOutDto searchKokyaku(jp.co.nri.trial.sample.custsearch.service.dto.KokyakuSerivceInDto serviceInDto) {
	
		jp.co.nri.trial.sample.custsearch.logic.dto.KokyakuLogicInDto logicInDto = (jp.co.nri.trial.sample.custsearch.logic.dto.KokyakuLogicInDto) mapper.map(serviceInDto, jp.co.nri.trial.sample.custsearch.logic.dto.KokyakuLogicInDto.class);
		jp.co.nri.trial.sample.custsearch.logic.dto.KokyakuLogicOutDto logicOutDto = kokyakuSearchLogic.searchKokyaku(logicInDto);
		jp.co.nri.trial.sample.custsearch.service.dto.KokyakuServiceOutDto serviceOutDto = (jp.co.nri.trial.sample.custsearch.service.dto.KokyakuServiceOutDto) mapper.map(logicOutDto, jp.co.nri.trial.sample.custsearch.service.dto.KokyakuServiceOutDto.class);
		
		return serviceOutDto;
	}

}
