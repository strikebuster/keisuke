package jp.co.nri.trial.sample.custsearch.logic;

import javax.ejb.Local;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎 
 */
@Local
public interface TradeSearchLogic {

	jp.co.nri.trial.sample.custsearch.logic.dto.TradeLogicOutDto searchTrade(jp.co.nri.trial.sample.custsearch.logic.dto.TradeLogicInDto logicInDto);

}
