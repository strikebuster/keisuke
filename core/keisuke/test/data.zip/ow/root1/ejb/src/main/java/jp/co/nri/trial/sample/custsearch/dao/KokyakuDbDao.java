package jp.co.nri.trial.sample.custsearch.dao;

import java.util.List;

import jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku;
import jp.co.nri.trial.sample.custsearch.dao.dto.KokyakuCondition;

/**
 * 顧客情報取得のインターフェースクラスです。
 * create-date 08/08/01.
 * @author 野村 太郎
 */
public interface KokyakuDbDao {
	
	/**
	 * selectByMultiKeys
	 */
	public List<Kokyaku> selectByMultiKeys(KokyakuCondition kokyakuCondition);
}
