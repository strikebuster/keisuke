package jp.co.nri.trial.sample.custsearch.service.dto;

import java.io.Serializable;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎 
 */
public class KokyakuServiceOutDto implements Serializable {
	private static final long serialVersionUID = 1L;

	@jp.co.nri.kinshasa.aplcommons.annotation.Label("顧客一覧")
	private java.util.List<jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku> kokyakulist;

	public void setKokyakulist(java.util.List<jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku> kokyakulist) {
		this.kokyakulist = kokyakulist;
	}

	public java.util.List<jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku> getKokyakulist() {
		return this.kokyakulist;
	}


}
