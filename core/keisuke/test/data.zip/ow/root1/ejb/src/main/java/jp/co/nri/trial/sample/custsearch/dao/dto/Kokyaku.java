package jp.co.nri.trial.sample.custsearch.dao.dto;

import java.io.Serializable;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎
 */
public class Kokyaku implements Serializable {
	private static final long serialVersionUID = 1L;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("6")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("顧客コード")
	private String kokyaku_cd;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("50")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("顧客名称（漢字）")
	private String kokyaku_name;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("6")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("担当者コード")
	private String tanto_cd;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSFormatPattern(pattern = ("####/##/##"))
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckDate
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("8")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("取引開始日")
	private String start_date;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckInteger
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("10")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("取引件数")
	private java.math.BigDecimal kensu;

	@jp.co.nri.kinshasa.aplcommons.annotation.Label("ステータス")
	private String kokyaku_status;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("50")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("顧客名称（カナ）")
	private String kokyaku_kana;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("50")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("住所１")
	private String kokyaku_addr;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckHankaku
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckAlphabetAndNumber
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("12")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("電話番号（代表）")
	private String kokyaku_tel;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckHankaku
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckAlphabetAndNumber
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("12")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("FAX番号（代表）")
	private String kokyaku_fax;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckHankaku
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckAlphabetAndNumber
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("50")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("e-mailアドレス")
	private String kokyaku_mail;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckInteger
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("10")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("従業員数")
	private java.math.BigDecimal kokyaku_ninzu;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("20")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("代表者名")
	private String kokyaku_president_name;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSFormatPattern(pattern = ("#,###,###,##0"))
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckInteger
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("10")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("資本金")
	private java.math.BigDecimal kokyaku_shihon;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSFormatPattern(pattern = ("####/##/##"))
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckDate
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("8")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("設立年月日")
	private String kokyaku_date;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("20")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("業種")
	private String kokyaku_gyosyu;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("100")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("業務内容")
	private String kokyaku_naiyo;

	public void setKokyaku_cd(String kokyaku_cd) {
		this.kokyaku_cd = kokyaku_cd;
	}

	public String getKokyaku_cd() {
		return this.kokyaku_cd;
	}

	public void setKokyaku_name(String kokyaku_name) {
		this.kokyaku_name = kokyaku_name;
	}

	public String getKokyaku_name() {
		return this.kokyaku_name;
	}

	public void setTanto_cd(String tanto_cd) {
		this.tanto_cd = tanto_cd;
	}

	public String getTanto_cd() {
		return this.tanto_cd;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public String getStart_date() {
		return this.start_date;
	}

	public void setKensu(java.math.BigDecimal kensu) {
		this.kensu = kensu;
	}

	public java.math.BigDecimal getKensu() {
		return this.kensu;
	}

	public void setKokyaku_status(String kokyaku_status) {
		this.kokyaku_status = kokyaku_status;
	}

	public String getKokyaku_status() {
		return this.kokyaku_status;
	}

	public void setKokyaku_kana(String kokyaku_kana) {
		this.kokyaku_kana = kokyaku_kana;
	}

	public String getKokyaku_kana() {
		return this.kokyaku_kana;
	}

	public void setKokyaku_addr(String kokyaku_addr) {
		this.kokyaku_addr = kokyaku_addr;
	}

	public String getKokyaku_addr() {
		return this.kokyaku_addr;
	}

	public void setKokyaku_tel(String kokyaku_tel) {
		this.kokyaku_tel = kokyaku_tel;
	}

	public String getKokyaku_tel() {
		return this.kokyaku_tel;
	}

	public void setKokyaku_fax(String kokyaku_fax) {
		this.kokyaku_fax = kokyaku_fax;
	}

	public String getKokyaku_fax() {
		return this.kokyaku_fax;
	}

	public void setKokyaku_mail(String kokyaku_mail) {
		this.kokyaku_mail = kokyaku_mail;
	}

	public String getKokyaku_mail() {
		return this.kokyaku_mail;
	}

	public void setKokyaku_ninzu(java.math.BigDecimal kokyaku_ninzu) {
		this.kokyaku_ninzu = kokyaku_ninzu;
	}

	public java.math.BigDecimal getKokyaku_ninzu() {
		return this.kokyaku_ninzu;
	}

	public void setKokyaku_president_name(String kokyaku_president_name) {
		this.kokyaku_president_name = kokyaku_president_name;
	}

	public String getKokyaku_president_name() {
		return this.kokyaku_president_name;
	}

	public void setKokyaku_shihon(java.math.BigDecimal kokyaku_shihon) {
		this.kokyaku_shihon = kokyaku_shihon;
	}

	public java.math.BigDecimal getKokyaku_shihon() {
		return this.kokyaku_shihon;
	}

	public void setKokyaku_date(String kokyaku_date) {
		this.kokyaku_date = kokyaku_date;
	}

	public String getKokyaku_date() {
		return this.kokyaku_date;
	}

	public void setKokyaku_gyosyu(String kokyaku_gyosyu) {
		this.kokyaku_gyosyu = kokyaku_gyosyu;
	}

	public String getKokyaku_gyosyu() {
		return this.kokyaku_gyosyu;
	}

	public void setKokyaku_naiyo(String kokyaku_naiyo) {
		this.kokyaku_naiyo = kokyaku_naiyo;
	}

	public String getKokyaku_naiyo() {
		return this.kokyaku_naiyo;
	}


}
