package jp.co.nri.trial.sample.phonebook.dao.impl;

import java.util.List;

import jp.co.nri.trial.sample.phonebook.dao.PhoneDbDao;
import jp.co.nri.trial.sample.phonebook.dao.dto.Phone;
import jp.co.nri.trial.sample.phonebook.dao.mapper.PhoneSqlClient;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;

/**
 * 電話帳検索ロジックの実装です。
 * create-date 01/08/2008.
 * @author 野村 太郎
 */
@Name("phoneDbDao")
public class PhoneDbDaoImpl implements PhoneDbDao {
	
	@In(create=true)
	private PhoneSqlClient phoneSqlClient;
	
	/**
	 * searchPhoneNo
	 * 電話帳一覧情報を取得する
	 * create-date 01/08/2008.
	 * @author 野村 太郎
	 */
	public List<Phone> searchPhoneNo() {

		List<Phone> result = null;

		//クエリの実行
		result = ★未完成部分：SQL Mapperクラスの電話帳一覧情報取得処理メソッドを呼び出してください ★

		return result;
	}

	/**
	 * insert
	 * 入力された携帯電話をDBに登録する
	 * param1 phone : 携帯電話
	 * create-date 01/08/2008.
	 * @author 野村 太郎
	 */
	public int insert(Phone phone) {

		System.out.print("●●● Phone insert START");

		// データを登録する
		int resultCnt = phoneSqlClient.insert(phone);

		System.out.print("●●● Phone insert END");

		return resultCnt;
	}
	
	/**
	 * delete
	 * 入力された携帯電話に一致する電話帳のデータを削除する
	 * param1 phone : 携帯電話
	 * create-date 01/08/2008.
	 * @author 野村 太郎
	 */
	public int delete(Phone phone) {

		System.out.print("●●● Phone delete START");

		// データを削除する
		int resultCnt = ★未完成部分：SQL Mapperクラスの携帯電話情報削除処理メソッドを呼び出してください ★

		System.out.print("●●● Phone delete END");

		return resultCnt;
	}
	
	/**
	 * selectByPhoneNo
	 * 入力された携帯電話番号に一致する電話帳の値を返す
	 * param1 phone : 携帯電話
	 * create-date 01/08/2008.
	 * @author 野村 太郎
	 */
	public Phone selectByPhoneNo(String phoneNo) {

		Phone result = null;

		//クエリの実行
		result = phoneSqlClient.selectByPhoneNo(phoneNo);

		return result;
	}
	
	/**
	 * update
	 * 入力された携帯電話に一致する電話帳のデータを更新する
	 * param1 phone : 携帯電話
	 * create-date 01/08/2008.
	 * @author 野村 太郎
	 */
	public int update(Phone phone) {

		System.out.print("●●● Phone update START");

		// データを更新する
		int resultCnt = phoneSqlClient.update(phone);

		System.out.print("●●● Phone update END");
		
		return resultCnt;
	}
	
}
