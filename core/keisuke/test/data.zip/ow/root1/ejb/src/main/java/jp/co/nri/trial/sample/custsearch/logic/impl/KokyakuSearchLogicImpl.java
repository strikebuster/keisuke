package jp.co.nri.trial.sample.custsearch.logic.impl;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;

import jp.co.nri.kinshasa.aplcommons.model.Aina;
import jp.co.nri.kinshasa.aplcommons.model.Mina;
import jp.co.nri.kinshasa.aplcommons.util.mapping.BeanMappingUtil;
import jp.co.nri.kinshasa.aplcommons.util.mapping.IMapper;
import jp.co.nri.kinshasa.framework.log.LogManager;
import jp.co.nri.kinshasa.framework.log.Logger;
import jp.co.nri.trial.sample.custsearch.dao.KokyakuDbDao;
import jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku;
import jp.co.nri.trial.sample.custsearch.dao.dto.KokyakuCondition;
import jp.co.nri.trial.sample.custsearch.logic.KokyakuSearchLogic;
import jp.co.nri.trial.sample.custsearch.common.LogMessage;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎 
 */
@Stateless
@Name("kokyakuSearchLogic")
public class KokyakuSearchLogicImpl implements KokyakuSearchLogic {

	@In(create = true)
	private KokyakuDbDao kokyakuDbDao;
	
	@In
	private Aina aina;

	private IMapper mapper = BeanMappingUtil.getInstance();

	//ログ出力部品の定義
	protected Logger logger = LogManager.getLogger(KokyakuSearchLogicImpl.class);

	//定数の定義
	private final String SUCCESS_MSG = "";
	private final String ERR_MSG_NO_KOKYAKU_RESULT = "検索条件に該当する顧客情報は見つかりませんでした";
	
	/**
	 * 任意条件検索
	 */
	public jp.co.nri.trial.sample.custsearch.logic.dto.KokyakuLogicOutDto searchKokyaku(
			jp.co.nri.trial.sample.custsearch.logic.dto.KokyakuLogicInDto logicInDto) {
		
		// DAOの呼び出し、検索実行
		KokyakuCondition kokyakuCondition = (KokyakuCondition)mapper.map(logicInDto, KokyakuCondition.class);

		// 検索条件を入力から設定する
		kokyakuCondition.setKokyaku_cd(logicInDto.getKokyaku_cd());
		kokyakuCondition.setKokyaku_name(logicInDto.getKokyaku_name());
		kokyakuCondition.setStart_date(logicInDto.getStart_date());
		kokyakuCondition.setTanto_cd(logicInDto.getTanto_cd());
		kokyakuCondition.setKokyaku_status(logicInDto.getSelected_kokyaku_status());

		List<Kokyaku> resultList = kokyakuDbDao.selectByMultiKeys(kokyakuCondition);

		// サービス層へ返すOutDtoの準備
		jp.co.nri.trial.sample.custsearch.logic.dto.KokyakuLogicOutDto logicOutDto = new jp.co.nri.trial.sample.custsearch.logic.dto.KokyakuLogicOutDto();

		// ステータス・メッセージのセットの準備
		Mina mina = new Mina();
		if (resultList.size() <= 0) {
			// 取得結果が無ければ、戻りステータスに検索失敗を設定
			mina.setMSG_TEXT_SUMMARY(ERR_MSG_NO_KOKYAKU_RESULT);
			aina.setSTATUS_CODE(1);
			logger.log(LogMessage.CSAPLLOG01);
		} else {
			// Kokyakuのリストを作成し、検索結果から値をマッピングしたKokyakuを加える
			logicOutDto.setKokyakulist(new ArrayList<Kokyaku>());
			for (Kokyaku result : resultList) {
				logicOutDto.getKokyakulist().add(
						(Kokyaku) mapper.map(result, Kokyaku.class));
			}
			
			mina.setMSG_TEXT_SUMMARY(SUCCESS_MSG);
			aina.setSTATUS_CODE(0);
			logger.log(LogMessage.CSAPLLOG02);
		}

		aina.addMESSAGES(mina);

		// 検索結果を格納したOutDto（KokyakuのList）を返す
		return logicOutDto;

	}

}
