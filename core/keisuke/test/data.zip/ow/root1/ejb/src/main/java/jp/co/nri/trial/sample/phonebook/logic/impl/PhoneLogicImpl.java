package jp.co.nri.trial.sample.phonebook.logic.impl;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;

import jp.co.nri.kinshasa.aplcommons.model.Aina;
import jp.co.nri.kinshasa.aplcommons.model.Mina;
import jp.co.nri.kinshasa.aplcommons.util.mapping.BeanMappingUtil;
import jp.co.nri.kinshasa.aplcommons.util.mapping.IMapper;
import jp.co.nri.kinshasa.framework.log.LogManager;
import jp.co.nri.kinshasa.framework.log.Logger;
import jp.co.nri.trial.sample.phonebook.dao.PhoneDbDao;
import jp.co.nri.trial.sample.phonebook.dao.dto.Phone;
import jp.co.nri.trial.sample.phonebook.common.LogMessage;
import jp.co.nri.trial.sample.phonebook.logic.PhoneLogic;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎
 */
@Stateless
@Name("phoneLogic")
public class PhoneLogicImpl implements PhoneLogic {

	@In(create=true)//コンテキストにPhoneDbDaoが存在しない場合は新たに生成します。 
	private PhoneDbDao phoneDbDao;
	
	@In
	private Aina aina;

	private IMapper mapper = BeanMappingUtil.getInstance();
	
	//ログ出力部品の定義
	protected Logger logger = LogManager.getLogger(PhoneLogicImpl.class);

	//定数の定義
	private final String STR_SUCCESS_MSG = "";
	private final String STR_ERR_MSG_NO_RESULT = "検索結果は見つかりませんでした";
	private final String SUCCESS_MSG_DE = "データを削除しました";
	private final String SUCCESS_MSG_ZERO_DE = "データの削除に失敗しました";
	private final String SUCCESS_MSG_IN = "データを新規登録しました";
	private final String SUCCESS_MSG_ZERO_IN = "データの新規登録に失敗しました";
	private final String SUCCESS_MSG_UP = "データを更新しました";
	private final String SUCCESS_MSG_ZERO_UP = "データの更新に失敗しました";
	
	/**
	 * 一覧検索
	 */
	public jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut001Dto searchphone(jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicIn001Dto logicInDto) {
		//DAOの呼び出し、検索実行
		List<Phone> result = phoneDbDao.searchPhoneNo();

		//サービス層へ返すOutDtoに電話帳情報データ作成
		jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut001Dto logicOutDto = new jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut001Dto();

		// ステータス・メッセージのセットの準備
		Mina mina = new Mina();
		
		if( result.size() > 0 ) {
			//検索結果が有る場合
			//結果を格納
			List<Phone> tmpoutDtoList = new ArrayList<Phone>();
			for(Phone tmpresult : result){
				Phone tmpPhone = (Phone) mapper.map(tmpresult,Phone.class);
				tmpoutDtoList.add(tmpPhone);
			}
			logicOutDto.setPhonelist(tmpoutDtoList);

			//取得結果によりログ出力を変更する。
			//Enumを使用したログメッセージ出力
			//正常終了のメッセージをセット
			mina.setMSG_TEXT_SUMMARY(STR_SUCCESS_MSG);
			logger.log(LogMessage.CS_D_APLLOG02, "");
		}else{
			//検索結果が無い場合
			//取得結果によりログ出力を変更する。
			//Enumを使用したログメッセージ出力
			//異常終了のメッセージをセット
			mina.setMSG_TEXT_SUMMARY(STR_ERR_MSG_NO_RESULT);
			logger.log(LogMessage.CS_D_APLLOG01, "");
		}
		aina.addMESSAGES(mina);
		aina.setSTATUS_CODE(0);

		return logicOutDto;
	}

	/**
	 * 一覧からの選択（実装なし）
	 */
	public jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut001Dto select(jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicIn001Dto logicInDto) {
		jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut001Dto logicOutDto = new jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut001Dto();
		return logicOutDto;
	}

	/**
	 * 単一行削除
	 */
	public jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut002Dto deletephone(jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicIn002Dto logicInDto) {
		//DAOの呼び出し、削除対象の行を取得
		Phone tmpPhone = phoneDbDao.selectByPhoneNo(logicInDto.getSelectedphonelist().getPhoneNo());

		//DAOの呼び出し、対象行を削除
		int resultCnt = ★未完成部分："DAOオブジェクト名.DAO削除メソッド名( 削除対象オブジェクト )" ★
		
		//ステータス・メッセージのセットの準備
		Mina mina = new Mina();
		
		if (resultCnt > 0){
			//削除成功の場合
			//正常終了のメッセージをセット
			mina.setMSG_TEXT_SUMMARY(SUCCESS_MSG_DE);
		}else{
			//削除失敗の場合
			//異常終了のメッセージをセット
			mina.setMSG_TEXT_SUMMARY(SUCCESS_MSG_ZERO_DE);
		}
		aina.addMESSAGES(mina);
		aina.setSTATUS_CODE(0);
		
		//一覧を再検索しセットして返す
		jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut002Dto logicOutDto = new jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut002Dto();
		logicOutDto.setPhonelist(this.searchphone(null).getPhonelist());

		return logicOutDto;
		
	}

	/**
	 * 単一行挿入
	 */
	public jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut001Dto createphone(jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicIn001Dto logicInDto) {
		//挿入する行を作成
		Phone tmpPhone = new Phone();
		tmpPhone.setPhoneNo(logicInDto.getPhoneNo());
		tmpPhone.setPhoneName(logicInDto.getPhoneName());
		tmpPhone.setPhoneAddress(logicInDto.getPhoneAddress());
		tmpPhone.setPhoneHouse(logicInDto.getPhoneHouse());
		tmpPhone.setPhoneBirthday(logicInDto.getPhoneBirthday());
		int resultCnt = phoneDbDao.insert(tmpPhone);
		
		// ステータス・メッセージのセットの準備
		Mina mina = new Mina();

		if (resultCnt > 0) {
			//挿入成功の場合
			//正常終了のメッセージをセット
			mina.setMSG_TEXT_SUMMARY(SUCCESS_MSG_IN);
		} else {
			//挿入失敗の場合
			//異常終了のメッセージをセット
			mina.setMSG_TEXT_SUMMARY(SUCCESS_MSG_ZERO_IN);
		}
		aina.addMESSAGES(mina);
		aina.setSTATUS_CODE(0);

		//一覧を再検索しセットして返す
		jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut001Dto logicOutDto = new jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut001Dto();
		logicOutDto.setPhonelist(this.searchphone(null).getPhonelist());

		return logicOutDto;
		
	}

	/**
	 * 単一行更新
	 */
	public jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut002Dto updatephone(jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicIn002Dto logicInDto) {
		//DAOの呼び出し、更新対象の行を取得
		Phone tmpPhone = phoneDbDao.selectByPhoneNo(logicInDto.getSelectedphonelist().getPhoneNo());

		//更新対象の行に入力された値を反映
		Phone inputPhoneDto = logicInDto.getSelectedphonelist();
		tmpPhone.setPhoneNo(inputPhoneDto.getPhoneNo());
		tmpPhone.★未完成部分："登録名設定メソッド( inputPhoneDto.登録名取得メソッド )" ★;
		tmpPhone.★未完成部分："登録住所設定メソッド( inputPhoneDto.登録住所取得メソッド )" ★;
		tmpPhone.★未完成部分："自宅電話番号設定メソッド( inputPhoneDto.自宅電話番号取得メソッド )" ★;
		tmpPhone.★未完成部分："生年月日設定メソッド( inputPhoneDto.生年月日取得メソッド )" ★;
		int resultCnt = phoneDbDao.update(tmpPhone);

		//ステータス・メッセージのセットの準備
		Mina mina = new Mina();
		
		if (resultCnt > 0) {
			//更新成功の場合
			//正常終了のメッセージをセット
			mina.setMSG_TEXT_SUMMARY(SUCCESS_MSG_UP);
		} else {
			//更新失敗の場合
			//異常終了のメッセージをセット
			mina.setMSG_TEXT_SUMMARY(SUCCESS_MSG_ZERO_UP);
		}
		aina.addMESSAGES(mina);
		aina.setSTATUS_CODE(0);
		
		//一覧を再検索しセットして返す
		jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut002Dto logicOutDto = new jp.co.nri.trial.sample.phonebook.logic.dto.PhoneLogicOut002Dto();
		logicOutDto.setPhonelist(this.searchphone(null).getPhonelist());

		return logicOutDto;
	}

}
