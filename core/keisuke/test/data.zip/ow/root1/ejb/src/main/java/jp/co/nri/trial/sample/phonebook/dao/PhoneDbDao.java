package jp.co.nri.trial.sample.phonebook.dao;

import java.util.List;

import jp.co.nri.trial.sample.phonebook.dao.dto.Phone;

/**
 * 電話帳情報取得のインターフェースクラスです。
 * create-date 01/08/2008.
 * @author 野村 太郎
 */
public interface PhoneDbDao {
	
	public List<Phone> searchPhoneNo();

	public int insert(Phone phone);

	public int delete(Phone phone);
	
	public Phone selectByPhoneNo(String phoneNo);
	
	public int update(Phone phone);

}
