package jp.co.nri.trial.sample.phonebook.action;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;

/**
 * insert画面用のページアクションクラス（初期処理）の実装です。
 * create-date 01/08/2008.
 * @author 野村 太郎
 */
@Name("insertPageAction")
public class InsertPageAction {

	@In(create=true)
	@Out
	protected jp.co.nri.trial.sample.phonebook.action.dto.PhoneBookWebDto phoneBookWebDto;

	public void init() {

		//web層Dtoの初期化
		phoneBookWebDto.setPhoneNo(null);
		phoneBookWebDto.setPhoneName(null);
		phoneBookWebDto.setPhoneAddress(null);
		phoneBookWebDto.setPhoneHouse(null);
		phoneBookWebDto.setPhoneBirthday(null);
	}

}
