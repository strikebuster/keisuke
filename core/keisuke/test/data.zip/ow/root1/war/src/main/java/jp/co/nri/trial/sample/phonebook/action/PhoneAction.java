package jp.co.nri.trial.sample.phonebook.action;

import org.jboss.seam.annotations.Name;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎
 */
@Name("phoneAction")
public class PhoneAction extends PhoneActionBase {
	// アクション層のみの空実装のためのオーバーライド
	@Override
	public String select(){
		
		// webDtoをインジェクションするためのアクセス
		String sDto = phoneBookWebDto.toString();
		aina.setSTATUS_CODE(0);
		
		return aina.getSTATUS_CODE().toString();
	}

}
