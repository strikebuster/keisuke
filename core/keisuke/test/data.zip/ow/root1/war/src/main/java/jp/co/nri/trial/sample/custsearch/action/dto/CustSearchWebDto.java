package jp.co.nri.trial.sample.custsearch.action.dto;

import static org.jboss.seam.ScopeType.CONVERSATION;

import java.io.Serializable;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.intercept.BypassInterceptors;


/**
 * create-date 01/08/2008.
 * @author 野村 太郎
 */
@Scope(CONVERSATION)
@Name("custSearchWebDto")
@BypassInterceptors
public class CustSearchWebDto implements Serializable {
	private static final long serialVersionUID = 1L;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("6")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("顧客コード")
	private String kokyaku_cd;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("50")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("顧客名称（漢字）")
	private String kokyaku_name;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("6")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("担当者コード")
	private String tanto_cd;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSFormatPattern(pattern = ("####/##/##"))
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckDate
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("8")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("取引開始日")
	private String start_date;

	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckInteger
	@jp.co.nri.kinshasa.aplcommons.annotation.KSSCheckMaxLength("10")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("取引件数")
	private java.math.BigDecimal kensu;

	@jp.co.nri.kinshasa.aplcommons.annotation.Label("選択されたステータス")
	private String selected_kokyaku_status;

	@jp.co.nri.kinshasa.aplcommons.annotation.Label("ステータス")
	private String kokyaku_status;

	@org.jboss.seam.annotations.datamodel.DataModel("kokyaku")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("顧客一覧")
	private java.util.List<jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku> kokyakulist;

	@org.jboss.seam.annotations.datamodel.DataModel("trade")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("取引一覧")
	private java.util.List<jp.co.nri.trial.sample.custsearch.dao.dto.Trade> tradelist;

	@org.jboss.seam.annotations.datamodel.DataModelSelection("kokyaku")
	@jp.co.nri.kinshasa.aplcommons.annotation.Label("選択された顧客")
	private jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku selected_kokyakulist;

	public void setKokyaku_cd(String kokyaku_cd) {
		this.kokyaku_cd = kokyaku_cd;
	}

	public String getKokyaku_cd() {
		return this.kokyaku_cd;
	}

	public void setKokyaku_name(String kokyaku_name) {
		this.kokyaku_name = kokyaku_name;
	}

	public String getKokyaku_name() {
		return this.kokyaku_name;
	}

	public void setTanto_cd(String tanto_cd) {
		this.tanto_cd = tanto_cd;
	}

	public String getTanto_cd() {
		return this.tanto_cd;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public String getStart_date() {
		return this.start_date;
	}

	public void setKensu(java.math.BigDecimal kensu) {
		this.kensu = kensu;
	}

	public java.math.BigDecimal getKensu() {
		return this.kensu;
	}

	public void setSelected_kokyaku_status(String selected_kokyaku_status) {
		this.selected_kokyaku_status = selected_kokyaku_status;
	}

	public String getSelected_kokyaku_status() {
		return this.selected_kokyaku_status;
	}

	public void setKokyaku_status(String kokyaku_status) {
		this.kokyaku_status = kokyaku_status;
	}

	public String getKokyaku_status() {
		return this.kokyaku_status;
	}

	public void setKokyakulist(java.util.List<jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku> kokyakulist) {
		this.kokyakulist = kokyakulist;
	}

	public java.util.List<jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku> getKokyakulist() {
		return this.kokyakulist;
	}

	public void setTradelist(java.util.List<jp.co.nri.trial.sample.custsearch.dao.dto.Trade> tradelist) {
		this.tradelist = tradelist;
	}

	public java.util.List<jp.co.nri.trial.sample.custsearch.dao.dto.Trade> getTradelist() {
		return this.tradelist;
	}

	public void setSelected_kokyakulist(jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku selected_kokyakulist) {
		this.selected_kokyakulist = selected_kokyakulist;
	}

	public jp.co.nri.trial.sample.custsearch.dao.dto.Kokyaku getSelected_kokyakulist() {
		return this.selected_kokyakulist;
	}


}
