package jp.co.nri.trial.sample.custsearch.action;

import org.jboss.seam.annotations.Name;

/**
 * create-date .
 * @author 
 */
@Name("kokyakuSearchAction")
public class KokyakuSearchAction extends KokyakuSearchActionBase {

}
