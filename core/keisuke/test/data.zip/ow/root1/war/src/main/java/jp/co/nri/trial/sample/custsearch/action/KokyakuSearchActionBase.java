package jp.co.nri.trial.sample.custsearch.action;

import jp.co.nri.kinshasa.aplcommons.model.Aina;
import jp.co.nri.kinshasa.aplcommons.util.mapping.BeanMappingUtil;
import jp.co.nri.kinshasa.aplcommons.util.mapping.IMapper;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Out;

/**
 * create-date 01/08/2008.
 * @author 野村 太郎 
 */
public class KokyakuSearchActionBase {

	@In(create = true)
	@Out
	protected jp.co.nri.trial.sample.custsearch.action.dto.CustSearchWebDto custSearchWebDto;

	@In(create = true)
	protected jp.co.nri.trial.sample.custsearch.service.KokyakuSearchService kokyakuSearchService;

	@In
	protected Aina aina;

	protected IMapper mapper = BeanMappingUtil.getInstance();

	public String searchKokyaku() {
		jp.co.nri.trial.sample.custsearch.service.dto.KokyakuSerivceInDto inDto =
				(jp.co.nri.trial.sample.custsearch.service.dto.KokyakuSerivceInDto) mapper.map(custSearchWebDto, jp.co.nri.trial.sample.custsearch.service.dto.KokyakuSerivceInDto.class);
		jp.co.nri.trial.sample.custsearch.service.dto.KokyakuServiceOutDto outDto = kokyakuSearchService.searchKokyaku(inDto);
		mapper.map(outDto, custSearchWebDto);
		return aina.getSTATUS_CODE().toString();
	}


}
