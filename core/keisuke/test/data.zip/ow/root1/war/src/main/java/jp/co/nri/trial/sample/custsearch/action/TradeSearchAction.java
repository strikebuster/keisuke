package jp.co.nri.trial.sample.custsearch.action;

import org.jboss.seam.annotations.Name;

/**
 * create-date .
 * @author 
 */
@Name("tradeSearchAction")
public class TradeSearchAction extends TradeSearchActionBase {

}
