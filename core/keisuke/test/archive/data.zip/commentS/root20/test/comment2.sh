#!/bin/sh

# hoge1
	#	hoge2
	#
chome="'HOGE4'"
whoami # hoge5b
###

echo 'that is good.'
echo "I said \"Hello.\" to him."

cat << EOF
Here are literal lines.
"hoge hoge"
### "moge moge"
EOF

