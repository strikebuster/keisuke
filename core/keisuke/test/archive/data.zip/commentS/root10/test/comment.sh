#!/bin/sh

# hoge1
	#	hoge2
	#
chome="'HOGE4'"
whoami # hoge5b
###

echo 'that is good.'
echo "I said \"Hello.\" to him."

cat <<EOF abc.txt > def.txt
Here are literal lines.
"hoge hoge"
### "moge moge"
EOF

