// hoge1　zzz コメント内は差分に出ない確認１
/*
hoge3 */
/*
*/ HOGE5zzz
HOGE6a /* hoge6b zzz コメント内は差分に出ない確認２
hoge7a */ HOGE7b


