package main

import (
	"fmt"
	"math"
	"time"
)

func add(x int, y int) int {
	/* comment */
	return x + y //comment
}

func pow(x, n, lim float64) float64 {
	if v := math.Pow(x, n); v < lim {
		return v
	} else {
		fmt.Printf("%g >= %g\n", v, lim)
	}
	// comment
	return lim
}

func greet() {
	t := time.Now()
	switch {
	case t.Hour() < 12:
		fmt.Println("Good morning!")
	case t.Hour() < 17:
		fmt.Println("Good afternoon.")
	default:
		fmt.Println("Good evening.")
	}
	/*
	switch {
	case t.Hour() < 12:
		fmt.Println("Bonjour!")
	case t.Hour() < 17:
		fmt.Println("Bonjour.")
	default:
		fmt.Println("Bonsoir.")
	}
	*/
}

func main() {
	var (
		apos rune = '\''
		quot rune = '"'
		backslash rune = '\\'
		text1 string = "Hello world"
		text2 string = "/* comment start"
		text3 string = `"new line" OK
// not comment
end`
		text4 string = " \"comment\" end */"
	)
	/* comment string "*/ //ignore
	sum := 0
	for i := 0; i < 10; i++ {
		sum = add(sum, i)
	}
	fmt.Println(sum)

	fmt.Println(
		pow(3, 2, 10), //ignore
		pow(3, 3, 20), //ignore
	)
	/* comment string "ignore"*/
	greet()
}

