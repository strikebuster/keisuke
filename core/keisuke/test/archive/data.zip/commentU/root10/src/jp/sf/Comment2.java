/* hoge1 */
/* hoge2a // hoge2b */
HOGE3
/* hoge4 */
// hoge5a /* hoge5b
HOGE6
/* hoge7 */
/* hoge8
// hoge9a */ HOGE9b
