// hoge1
/*
hoge3 */
/*
*/ HOGE5
HOGE6a /* hoge6b
hoge7a */ HOGE7b

// hoge9a /* hoge 9b
HOGE10
/* hoge11 */
/* hoge12a // hoge12b */
HOGE13
/* hoge14 */

chome = "// HOGE16 ";
chome = "HOGE17a // HOGE17b";
chome = " HOGE18 /* ";
chome = "HOGE19";
chome = " HOGE20a */ \n /* HOGE20b ";
HOGE21a // hoge21b
chome = " HOGE22a \"; /* HOGE22b ";
chome = " HOGE23a \'; /* HOGE23b '";
chome = " */"; HOGE24
chome = " HOGE25a \" \\"; /* hoge25b
hoge26a */ chome = " \' HOGE26b ; /* HOGE26c \\";
HOGE27
chome = "HOGE28 \t \n \' \" */";
