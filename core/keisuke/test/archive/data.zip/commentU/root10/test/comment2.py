#!/usr/bin/python
# coding: utf-8
HOGE3a # hoge3b
HOGE4 """ hoge4a 
hoge5
#hoge6a """ HOGE6b
#hoge7 '''
HOGE8 ''' hoge8b
""" hoge9
hoge10a ''' HOGE10b # hoge10c """
HOGE11

