//
    //
// hoge
    // hoge
hoge //
hoge // hoge
