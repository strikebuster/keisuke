// hoge1
/*
hoge3 */
/*
*/ HOGE5
HOGE6a /* hoge6b
hoge7a */ HOGE7b


