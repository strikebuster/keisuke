package jp.sf.amateras.diffcount;

public enum Status {
	ADDED, MODIFIED, REMOVED
}
