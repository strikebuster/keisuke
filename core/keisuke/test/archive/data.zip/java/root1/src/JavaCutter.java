package jp.sf.amateras.diffcount.cutter;

/**
 *
 * @author Naoki Takezoe
 *
 * [[Cutter]]
 */
public class JavaCutter implements Cutter {

	@Override
	public String cut(String source) {
		// TODO テスト
		StringBuilder sb = new StringBuilder();


		return sb.toString();
	}

}
