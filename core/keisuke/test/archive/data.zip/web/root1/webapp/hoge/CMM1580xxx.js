  /**
   * 告知メッセージの開閉ボタンを押下する際に開閉状態を保存・更新します。
   *
   * @author NRI重松
   */
function opencloseclick() {

        //非表示ボタン（開閉状態を保存・更新する機能）を押下する
        document.getElementById("openCloseSave").click();
        
}